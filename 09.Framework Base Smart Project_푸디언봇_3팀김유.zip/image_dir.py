import os
import pandas as pd

df = pd.read_csv('ramyeon_paldo_nutrient.csv', encoding='utf-8')
df2 = df.iloc[:,[0,1]]
print(df2)

file_list = os.listdir("C:/Estrella/Projects/Final_project/데이터전처리완료/images/ramyeon/paldo")
# print(file_list)

# images_dir = "./images/ramyeon/ottogi/" + file_list[0]
# print(images_dir)|

# 이미지 주소 반복문
a = 0
data = []
for a in range(len(file_list)):
    images_dir = "./images/ramyeon/paldo/" + file_list[a]
    a += 1
    data.append([images_dir])
# print(data)

# column = {'images': [i for i in data]}
df3 = pd.DataFrame(data)
print(df3)
df3.columns = ['images']
# df3.rename(index={'0':'images'}, inplace=True)

# result = pd.concat([df2, df3], how='left')
result = df2.join(df3, how='left')
print(result.columns)

result.to_csv('ramyeon_paldo_images.csv', header=True, index=False, encoding='cp949')