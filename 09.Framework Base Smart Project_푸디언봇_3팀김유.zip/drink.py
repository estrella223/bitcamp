# 광동제약
from urllib.request import urlopen
from bs4 import BeautifulSoup
import pandas as pd
import re


df2 = pd.read_csv('juice.csv', sep='\t')
print(df2)


url = 'http://www.ekdp.com/product/items_view.asp?s=351'
result = urlopen(url)
html = result.read()
soup = BeautifulSoup(html, 'html.parser')

td = str(soup.find('div', {'class': 'txt'}))    # 문자로 변환시킴
# print(td)
td_tag = re.sub('<.+?>', '', td, 0).strip()   # 태그 제거
# print(td_tag)
a = td_tag.split('[원재료명]')
# print(a)
aa = a[1]
# print(aa)
aaa = aa.split('[내용량/규격]')
# print(aaa)
a1 = aaa[0]
print(a1)

a2 = re.sub(r'\(.*?\)', '', a1, 0).strip()    # 괄호와 괄호안 문자 제거
print(a2)

a3 = a2.replace('유자과즙4%', '유자과즙')
a3 = a3.replace('한라봉주스농축액0.6%', '한라봉주스농충액')
print(a3)

a4 = a3.split(',')
print(a4)
#
data = {'비타500': [i for i in a4]}
df = pd.DataFrame(data)
df_T = df.T
print(df_T)
# df_T.to_csv('juice.csv')

df_T.to_csv('juice.csv', mode='a', header=False, index=True)