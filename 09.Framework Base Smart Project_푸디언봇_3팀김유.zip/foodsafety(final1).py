from urllib.request import urlopen
from bs4 import BeautifulSoup
import pandas as pd
import re
from html_table_parser import parser_functions as parser

url = 'https://www.foodsafetykorea.go.kr/iframe/specialinfo/prdInfoDetail.do?prdlstReportLedgNo=2016021000376763&from=searchCompany'
result = urlopen(url)
html = result.read()
soup = BeautifulSoup(html, 'html.parser')


table = soup.find_all('table')    # table 찾기
p = parser.make2d(table[4])    # table 인덱스 4번째값(원재료 나와있는 부분) 태그 제거후 텍스트만 불러와주는 함수
# print(p)

data = p[1:]    #원재료 재목부분 제거후 원재료명만 추출
print(data)


# 각 리스트의 [2] 값을 ()안에 넣기
a = 0    # 초기값(인덱스)을 0으로 세팅

for a in range(len(data)):
    if not data[a][2] == '':
        bb = "(" + data[a][2] + ")"
        data[a][2] = bb
        a += 1
        # print(p2)
print(data)


# 제품명
title_class = soup.find('div', {"class": "inqq-info"})
title = title_class.find('span').text
print(title)



# 데이터프레임화 시키기
df = pd.DataFrame(data, columns=["index", "성분 및 원료", "비고"])
df[title] = df["성분 및 원료"] + df["비고"]    # 새로운 열 생성
df2 = pd.DataFrame(df[title])    # "성분"열만 추출해서 새로운 데이터프레임 만들기
print(df2)

df3 = df2.T
# print(df3)


# 브랜드 자동 크롤링
brand_class = soup.find_all('table', {"class": "col table-sm"})
brand_class = brand_class[0]
# print(brand_class)
brand = brand_class.find('a').text
# print(brand)


# 데이터 프레임에 columns 추가
df3.insert(0, "제품명", title)
df3.insert(1, "브랜드", brand)
df3.insert(2, "분류", "스프류")
print(df3)


# csv 생성
# df3.to_csv('원재료_농심4.csv', mode='a', header=False, index=True, encoding='cp949')

data = pd.read_csv('원재료_농심4.csv', sep='\t', encoding='cp949')    # https://mskim8717.tistory.com/82
print(data)

print(data.iloc[0])